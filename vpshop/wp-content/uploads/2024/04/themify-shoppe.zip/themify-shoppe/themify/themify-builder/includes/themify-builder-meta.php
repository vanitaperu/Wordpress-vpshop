<?php

defined( 'ABSPATH' ) || exit;

/**
 * Builder Main Meta Box HTML
 */
?>
<div id="tb_builder_placeholder"></div><!-- /#will replaced - by js later -->
<div style="display: none;">
    <?php wp_editor( ' ', 'tb_lb_hidden_editor' ); ?>
</div>